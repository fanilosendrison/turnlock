# turnlock

> **turnlock gives scripts a deterministic spine with explicit semantic yield points.**
> It lets scripts run mechanical workflow steps in code, pause only when a consumer runtime must resolve semantic work, then resume automatically.
>
> Write a pipeline where code handles mechanical steps and every semantic delegation names its logical target.
> No manual handoff, polling, or restart from scratch: the script controls the flow while the consumer chooses how to execute each target.

---

Repository contribution rules and mandatory validation are defined in
[AGENTS.md](AGENTS.md). Issue routing and Project-specific work classification
are defined in the
[Turnlock Engineering profile](docs/repository-governance/turnlock-engineering.md).

## The problem

In Claude Code (or Codex, or Cursor), you can invoke a script from a skill:

```
User types /lint-fix  →  skill launches lint-fix.sh  →  script runs
```

But what about the reverse? **A script cannot durably yield semantic work to a logical actor and later resume.** Calling the current host context is one important case; invoking a named worker that a runtime maps to an agent session, direct model call, service, or process is another. Without an explicit protocol, the script is a blocked subprocess and its launcher is waiting for it to finish.

```
Without turnlock:
  ┌─────────────┐                          ┌──────────┐
  │  Host Agent │────── launches ────────▶ │ script.sh│
  └─────────────┘                          └──────────┘
         ▲                                       │
         │                                       │  needs host agent's project context
         │                  ❌                   │  (ex: /summarize-this-text)
         └───────────────────────────────────────┘
              script can't call the Host Agent back

With turnlock:
  ┌─────────────┐                          ┌──────────┐
  │   Launcher  │────── launches ────────▶ │ script.ts│
  └─────────────┘                          └──────────┘
         ▲                                       │
         │                                       │  yields an explicit target
         │               ┌──────────┐            │  host | worker(name)
         └───────────────│ consumer │◀───────────┘
                         │ runtime  │
                         └────┬─────┘
                              │ resolves target to
                              ▼ agent | model | service | process
```

And **leaving the orchestration to the agent is the problem**:

| Issue | Consequence |
|-------|-------------|
| **LLMs are non-deterministic** | Same input → different output. The agent might skip a step, reorder phases, or improvise. You can't guarantee the same pipeline runs the same way twice. |
| **Context pollution** | The agent carries the entire pipeline logic in its context window — consuming tokens on mechanical decisions (retry? next phase? validate schema?) that code should handle. |
| **Token waste** | Every mechanical decision the agent makes is a billed token. A 3-step pipeline with retries can burn thousands of tokens on flow control alone. |

**turnlock solves this by inverting control.** A TypeScript pipeline decides when semantic work is delegated and which logical target owns it. The pipeline is deterministic. Mechanical steps are code. Semantic steps cross a clean protocol whose physical execution is owned by the consumer runtime. If the process crashes mid-pipeline, `--resume` picks up exactly where it stopped.

The useful mental model: turnlock is the mechanical spine of a workflow. A phase is a persisted, resumable transaction in that spine. A delegation is the explicit yield point where the workflow needs semantic judgment, host-agent tools, or another non-deterministic worker.

---

## Quick example (30 seconds)

A pipeline that runs after the agent has written code: verify, delegate the commit message to a skill, then commit.

```typescript
import { runOrchestrator } from "turnlock";
import { z } from "zod";

runOrchestrator({
  name: "verify-and-commit",
  initial: "verify",
  phases: {
    verify: async (state, io) => {
      // Mechanical: tests pass, lint passes, typecheck passes
      // Delegate to a worker: write the commit message
      return io.delegate(
        { kind: "prompt", target: { kind: "worker", name: "commit-msg" }, prompt: "Write a conventional commit for the staged diff", label: "msg" },
        "commit",
        state,
      );
    },
    commit: async (state, io) => {
      const { message } = io.consumePendingResult(z.object({ message: z.string() }));
      // Mechanical: git commit with the agent-written message
      return io.done({ committed: true, message });
    },
  },
  initialState: {},
  resumeCommand: (runId) => `node pipeline.js --run-id ${runId} --resume`,
});
```

**What happens at runtime:**

1. `verify` runs once. Checks pass, then it calls `io.delegate(...)`.
2. The runtime snapshots state to disk, prints a `@@TURNLOCK@@` protocol block on stdout, and **exits**.
3. The consumer runtime reads the protocol block, resolves the logical target (here: `worker("commit-msg")`) to its chosen physical execution mechanism, waits for completion, then relaunches the binary with `--resume --run-id <id>`. A Claude Code host agent is one possible consumer, not the only executor model.
4. On resume, authoritative state is loaded from SQLite and `state.json` is repaired or regenerated as a projection. `commit` runs, consumes the skill's result, commits with the agent-written message, and emits `DONE`.

Notice that a phase is not synonymous with an agent call. A phase can do as much mechanical work as it needs before yielding. Splitting into another phase is reserved for durable boundaries: `delegate(...)`, `delegateBatch(...)`, `requestExternal(...)`, `done(...)`, or `fail(...)`.

Turnlock itself runs on Node.js. `resumeCommand` remains opaque consumer data, so a host may still provide a command targeting another runtime, including Bun; Turnlock emits that command but never executes it.

---

## How it works

```
┌──────────────────────────────────────────────────────────────┐
│                      TURNLOCK PIPELINE                        │
│                                                              │
│   Phase 1            Phase 2             Phase 3             │
│  (mechanical)       (delegation)        (mechanical)         │
│  ┌──────────┐      ┌──────────┐        ┌──────────┐         │
│  │   Lint   │─────▶│  Delegate│        │  Verify  │         │
│  │  (code)  │      │ (suspend)│        │  (code)  │         │
│  └──────────┘      └────┬─────┘        └────▲─────┘         │
│                         │                   │                │
│          ┌──────────────┼───────────────────┼─────────────┐  │
│          │  PROTOCOL    │                   │             │  │
│          │              ▼                   │             │  │
│          │  @@TURNLOCK@@                     │             │  │
│          │  action: DELEGATE                │             │  │
│          │  run_id: 01J...                  │             │  │
│          │  resume_cmd: node ...            │             │  │
│          │  @@END@@                         │             │  │
│          │                                  │             │  │
│          │  Process exits (code 0)          │             │  │
│          │         │                        │             │  │
│          │         ▼                        │             │  │
│          │  ┌────────────────────┐         │             │  │
│          │  │  Consumer runtime  │         │             │  │
│          │  │  resolves target   │         │             │  │
│          │  │  selects execution │         │             │  │
│          │  │  writes result to  │         │             │  │
│          │  │  $RUN_DIR/results/ │         │             │  │
│          │  └────────┬───────────┘         │             │  │
│          │           │                     │             │  │
│          │           ▼                     │             │  │
│          │  ┌────────────────────┐         │             │  │
│          │  │  Resume process    │─────────┼─────────────┘  │
│          │  │  loads SQLite state│         │                │
│          │  │  consumes result   │─────────┘                │
│          │  │  continues at      │                          │
│          │  │  Phase 3           │                          │
│          │  └────────────────────┘                          │
│          └─────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

**The key insight:** turnlock doesn't run a persistent server. It starts, executes mechanical phases until it hits a delegation, snapshots state, and **exits**. The consumer runtime resolves and executes the logical target, then relaunches Turnlock. This means Turnlock itself keeps nothing running while the workflow is yielded — no memory leaks, dangling Turnlock processes, or port conflicts.

---

## Why turnlock instead of...

### ...a Bash script?

```bash
#!/bin/bash
# What you WANT to do:
pnpm exec biome check src/ > lint-output.json
if [ $? -ne 0 ]; then
  # ❌ Impossible: you can't invoke a Claude Code skill from Bash.
  # You have to stop here, tell the user to run /fix-lint manually,
  # then tell them to re-run this script.
  echo "Run /fix-lint in Claude Code, then re-run this script."
  exit 1
fi
pnpm exec biome check src/  # verify
```

```typescript
// What turnlock lets you do:
const lint = async (state, io) => {
  const errors = findLintErrors(state.files);
  if (errors.length === 0) return io.done({ ok: true });
  return io.delegate(
    {
      kind: "prompt",
      target: { kind: "host" },
      prompt: `Fix: ${JSON.stringify(errors)}`,
      label: "fix",
    },
    "verify",
    { ...state, errors },
  ); // ← suspends; the runtime resolves host, then resumes at "verify"
});
```

| Concern | Bash script | turnlock |
|---------|-------------|----------|
| Yield semantic work from code | ❌ Impossible | ✅ `io.delegate(...)` |
| Crash recovery | ❌ Restart from scratch | ✅ embedded SQLite authority + `--resume` |
| Structured audit trail | ❌ Ad-hoc `echo` | ✅ `events.ndjson` + manifests |
| Retry on transient errors | ❌ Manual trap/retry | ✅ Built-in backoff + timeout |
| JSON manipulation | ❌ `jq` chains, fragile | ✅ Native TS + zod validation |
| Deterministic flow | ❌ Discipline-only | ✅ Frozen state, single-result guard, fenced SQLite ownership |

### ...Temporal / Inngest / Trigger.dev?

Temporal is a fantastic workflow engine — for distributed systems with a server. turnlock is designed for environments where **no server can exist**: a CI runner, a laptop, a Claude Code session. No Docker, no external database service, no worker pool — a single process that starts, runs, and exits. If you have a Temporal cluster, use Temporal. If you're inside an agent session, use turnlock.

### ...an AI SDK (Vercel AI, LangChain)?

AI SDKs are for chaining LLM calls. turnlock is for chaining **mechanical and agent steps** with reliability guarantees. Turnlock itself does not execute semantic workers: it emits durable delegation requests to logical targets (`host` or `worker(name)`). The surrounding runtime or consumer decides how each target is satisfied — by the current host agent, a child agent session, a direct model call, a remote service, or another execution mechanism.

Turnlock knows:

```text
target = worker("reviewer")
```

Turnlock does NOT know:

```text
reviewer = Pi child using model X
```

That resolution belongs to the consumer runtime. Different layer.

### ...an in-process FSM library (XState, etc.)?

If you don't need crash recovery or auditability, a state-machine library in a long-running process is simpler. turnlock adds snapshot persistence, a delegation protocol, and resume-by-relaunch. Use it when "the script might die mid-pipeline and must recover exactly where it was."

**The through-line: lightweight.** Every alternative above brings a server, a framework, or a stack of dependencies. turnlock ships **2 production dependencies** (`zod`, `ulid`), runs as a single process that starts and exits, and requires zero infrastructure. No Docker, no external database service, no queue, no daemon. It uses an embedded, same-host SQLite database inside each run directory. Clone it, read the README, write your first pipeline in 10 minutes.

---

## Core properties

**Determinism.** The orchestration logic lives in your TypeScript code, not in the agent's judgment. Given the same state, turnlock always picks the same next yield. State is deep-frozen before each phase — no accidental mutation.

**Reliability.** Every stable phase yield snapshots state to a SQLite-authoritative store with fenced CAS ownership. `state.json` is a projection regenerated from the authority on resume. `--resume` continues snapshots suspended on a pending delegation or External Request. Turnlock does not currently replay a freely executing phase after a crash.

**Auditability.** Each run produces a SQLite-authoritative state store, a projected `state.json` snapshot, an append-only `events.ndjson` audit trail, and JSON manifests for yielded requests — all correlated by `run_id`. `state.json` is a readable projection; SQLite holds the authority.

**Host-agnostic.** Delegation requests travel over stdout in a neutral protocol (`@@TURNLOCK@@ ... @@END@@`). Any host that can read them, resolve the logical target, execute the work, and relaunch the binary is a valid consumer. Claude Code is the reference integration; Codex, Cursor, and custom scripts are all valid.

## Explicit orchestration: shape, target, execution

Turnlock separates three orthogonal axes of delegation (see [ADR-0001](docs/adr/0001-logical-delegation-targets.md) and the [delegation model](docs/architecture/delegation-model.md)):

| Axis | Meaning | Examples |
| ---- | ------- | -------- |
| Delegation shape | structure of semantic work | `prompt`, `batch` |
| Logical target | who logically owns the work | `host`, `worker("reviewer")` |
| Physical execution | how the runtime satisfies the target | Pi child, LLM API, service |

`host` means the principal semantic actor of the harness that launched the workflow, in the current host context. `worker(name)` is a named logical execution capability — never a specific subprocess, session, model, or provider. The runtime resolves the target; Turnlock only records it.

Delegation/orchestration is explicit in the workflow rather than emerging implicitly from the main agent's hidden behavior:

```text
deterministic phase
    ↓
worker("researcher") batch
    ↓
results collected
    ↓
host synthesis delegation
    ↓
deterministic phase
    ↓
worker("reviewer")
```

---

## Shared workspace and resource safety

Turnlock isolates durable workflow authority by run; it does **not** make the
workspace or another external mutable resource exclusive to that run. Two
independent runs may be valid and concurrently authoritative while still having
access to the same files, Git index, repository refs, remote branch, database,
or API resource.

The boundary is explicit:

```text
run ownership    != resource ownership
run fencing      != resource fencing
run-state safety != external-effect safety
```

The consumer/runtime owns the physical execution context, the domain
orchestrator owns knowledge of resource conflicts and concurrency policy, and a
resource-aware system must enforce any required worktree isolation, lease,
fencing token, CAS, transaction, or other serialization mechanism. Turnlock
Core does not infer those semantics from `cwd`, paths, Git metadata, or External
Request payloads.

A Turnlock run reaching `DONE` therefore proves a valid terminal workflow
transition, not that concurrent external business effects were correctly
serialized. See [ADR-0003](docs/adr/0003-shared-resource-safety-boundary.md) and
the [shared resource safety boundary](docs/architecture/resource-safety-boundary.md).

---

## External effects and robustness levels

Turnlock does not make phases transactional. Consumers choose the robustness level that matches each external effect. Existing delegation remains the level for agent work with Turnlock's delegation retry policy; External Requests use a separate, non-retrying path.

### Direct effect

A phase may perform an effect directly:

```typescript
async function phase(state, io) {
  await externalEffect();
  return io.done(state);
}
```

**Guarantee:** Turnlock provides no guarantee for this effect. If the process dies during a freely executing phase, normal `--resume` refuses to continue because there is no pending yield. The effect's outcome may therefore be unknown and requires consumer- or operator-defined recovery. Turnlock neither automatically replays nor deduplicates that phase.

### External Request

A phase may instead suspend durably until a consumer supplies an opaque JSON resolution:

```typescript
const phases = {
  push: async (state, io) =>
    io.requestExternal(
      {
        label: "push-repo-a",
        requestType: "git.push",
        payload: {
          repository: "/repo-a",
          remote: "origin",
          branch: "main",
          targetSha: "abc123",
        },
      },
      "after-push",
      state,
    ),

  "after-push": async (state, io) => {
    const resolution = io.consumePendingExternalResolution(
      z.object({
        outcome: z.enum(["PUSHED", "REJECTED", "UNKNOWN"]),
        remoteSha: z.string().optional(),
      }),
    );
    return io.done({ state, resolution });
  },
};
```

**Guarantee:** the suspended state records a SHA-256 digest of the exact request manifest bytes. Every resume verifies that digest before re-emission, so `requestId` cannot remain stable while payload, metadata, formatting, or other manifest content changes. Turnlock treats the request and resolution as opaque JSON and leaves business validation to the phase's Zod schema.

At the first syntactically valid JSON resolution, Turnlock atomically preserves the exact bytes under `accepted-external-resolutions/<label>.json`, records its path, digest, and acceptance time in `state.json`, and only then runs the continuation phase. A crash before the phase's next stable transition reuses that accepted copy, never a changed consumer result. A syntactically valid but schema-invalid resolution is therefore still pinned and cannot be replaced under the same request identity.

**Limit:** Turnlock does not perform, retry, reconcile, compensate, or interpret the external effect. If no resolution is written, the workflow remains suspended without an implicit success, failure, business timeout, or effect retry. Each explicit resume attempt can re-publish the same request identity, manifest, and result path. Turnlock does not guarantee that a host will relaunch the process or receive a publication, and re-publication is not an instruction to retry the effect.

The consumer should write the candidate resolution through a temporary file, flush it when required by its durability model, and atomically rename it to the manifest's `resultPath` before running `resume_cmd`. Turnlock owns the accepted copy and never executes the external effect.

Turnlock 0.12.0 emits protocol version 3, state schema version 4, delegation manifest version 3, and internal SQLite authority schema version 3. The SQLite schema records workflow terminality independently from execution ownership and retention state. It migrates older SQLite authorities conservatively: a verified durable `terminalResult` proves `DONE`; every ambiguous, suspended, or indeterminate workflow remains nonterminal. It also retains the existing state-v2/v3 and delegation-manifest-v2 migration paths where the historical destination is unambiguous. Older Turnlock releases cannot read schema-v3 SQLite authorities, and consumers must recognize `REQUEST_EXTERNAL` before handling that yield type.

Retention applies only after an explicit `io.done()` or `io.fail()` transition has atomically terminalized the workflow. `FREE` ownership or an expired ownership lease proves only that no process currently owns execution; neither makes a suspended workflow eligible for deletion. Turnlock has no implicit abandonment or orphan timeout. A nonterminal run remains retained until an explicit future policy establishes otherwise.

> `requestExternal()` is optional. It should be used only when a consumer wants to suspend the workflow durably while waiting for an external resolution.

## What turnlock is NOT

- **Not a distributed workflow engine** — Temporal does that better at scale, with a server. turnlock runs where Temporal cannot: CI runners, laptops, inside agent sessions.
- **Not an LLM router** — if you only need to chain a few LLM calls across providers, an AI SDK in a plain Node script is simpler. turnlock is worth it when you're orchestrating multiple phases, some mechanical and some agent-delegated, with reliability and audit guarantees.
- **Not an in-process FSM library** — if neither reliability nor auditability matters, a state-machine lib in a long-running process is simpler.
- **Not an agent framework** — Turnlock does not choose a physical executor. It constrains when semantic work is yielded and records its logical target; the consumer runtime resolves and executes that target.

One nice consequence: **testability comes for free.** Phases are pure TypeScript functions with declarative delegations, trivially unit-testable in isolation. Transition graphs can be property-tested with `fast-check` (see `tests/`).

---

## Getting started

### Prerequisites

- Node.js ≥ 22.19.0
- pnpm 11.24.0

### Install

```bash
git clone git@github.com:fanilosendrison/turnlock.git
cd turnlock
pnpm install --frozen-lockfile
```

### Verify

```bash
pnpm test          # unit + integration + property tests
pnpm run typecheck # strict tsc --noEmit
pnpm run lint      # biome check src/ tests/ scripts/
```

### Build

```bash
pnpm run build     # emit ./dist from src/
```

---

## Documentation

| Resource | Description |
|----------|-------------|
| [`docs/adr/`](docs/adr/) | Architecture Decision Records (why decisions were made) |
| [`docs/architecture/delegation-model.md`](docs/architecture/delegation-model.md) | Current delegation model: shape, logical target, runtime execution |
| [`docs/architecture/resource-safety-boundary.md`](docs/architecture/resource-safety-boundary.md) | Shared workspace and external-resource safety responsibilities |
| [`docs/sqlite-ownership-migration.md`](docs/sqlite-ownership-migration.md) | **Upgrade guide**: migrating from legacy `.lock` to SQLite ownership |
| [`docs/migrations/node-pnpm/`](docs/migrations/node-pnpm/) | Bun → Node/pnpm migration notes and parity contract |

---

## License

MIT
